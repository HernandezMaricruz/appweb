import { Component } from '@angular/core';

@Component({
  selector: 'app-vista',
  standalone: true,
  imports: [],
  templateUrl: './vista.component.html',
  styleUrl: './vista.component.css'
})
export class VistaComponent {

}
