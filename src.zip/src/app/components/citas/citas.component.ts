import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpCitasService } from '../../services/http-citas.service';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from "../header/header.component";
import { VistaComponent } from "../vista/vista.component";

@Component({
  selector: 'app-citas',
  standalone: true,
  imports: [FormsModule, CommonModule, ReactiveFormsModule, HeaderComponent, VistaComponent],
  templateUrl: './citas.component.html',
  styleUrls: ['./citas.component.css']
})
export class CitasComponent implements OnInit {
  citasForm: FormGroup;
  citas: any[] = [];
  fechaConsulta: string = '';

  constructor(private formBuilder: FormBuilder, private citasService: HttpCitasService) {
    this.citasForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      fecha: ['', Validators.required],
      hora: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  agendarCita() {
    const nuevaCita = this.citasForm.value;
    this.citasService.agendarCita(nuevaCita).subscribe({
      next: () => {
        alert('Cita agendada exitosamente');
        this.citasForm.reset();
      },
      error: () => alert('Error al agendar la cita')
    });
  }

  verCitasDelDia() {
    this.citasService.getCitasPorDia(this.fechaConsulta).subscribe((data) => {
      this.citas = data;
    });
  }

  verTodasLasCitas() {
    this.fechaConsulta = ''; // Limpiar la fecha de consulta
    this.citasService.getTodasLasCitas().subscribe((data) => {
      this.citas = data.sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());
    });
  }

  eliminarCita(id: number) {
    this.citasService.eliminarCita(id).subscribe({
      next: () => {
        alert('Cita eliminada');
        this.verCitasDelDia();
        this.citasService.getTodasLasCitas().subscribe((data) => {
          this.citas = data.sort((a, b) => new Date(a.fecha).getTime() - new Date(b.fecha).getTime());
        });
      },
      error: () => alert('Error al eliminar la cita')
    });
  }
}
