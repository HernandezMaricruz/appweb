import { Component, inject } from '@angular/core';
import { RouterOutlet, RouterLink, Router } from '@angular/router';
import { CitasComponent } from '../../components/citas/citas.component';
import { HorariosComponent } from '../../paginas/horarios/horarios.component';
import { InformacionComponent } from '../../paginas/informacion/informacion.component';
import { InicioComponent } from '../../paginas/inicio/inicio.component';
import { InventarioComponent } from '../../paginas/inventario/inventario.component';
import { BuscarComponent } from '../../paginas/inventario/buscar/buscar.component';
import { InisecionComponent } from "../inisecion/inisecion.component";


@Component({
  selector: 'app-menu',
  standalone: true,
  imports: [RouterOutlet, RouterLink, InisecionComponent],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent {
  router: any;  

  /*inisecion:InisecionComponent = inject(InisecionComponent)
  constructor(router:Router, private inisecionComponent:InisecionComponent){
    this.router.router;
  }*/
  
}
