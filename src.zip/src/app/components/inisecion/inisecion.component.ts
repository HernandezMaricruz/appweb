import { CommonModule } from '@angular/common';
import { Component, inject, OnInit} from '@angular/core';
import { ReactiveFormsModule, Validators, FormBuilder} from '@angular/forms';
import { Router, RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { HttpsLoginsService } from '../../services/https-logins.service';
import { UserserviceService } from '../../services/userservice.service';
import { HttpUsuarioService } from '../../services/http-usuario.service';

import { MatTabsModule } from '@angular/material/tabs';
import {DatePipe} from '@angular/common';


@Component({
  selector: 'app-inisecion',
  standalone: true,
  imports: [ReactiveFormsModule, MatTabsModule, DatePipe, RouterLink, RouterOutlet, RouterLinkActive],
  templateUrl: './inisecion.component.html',
  styleUrls: ['./inisecion.component.css']
})
export class InisecionComponent {
  router:any;
  formbuilder = new FormBuilder;
  loginGroup = this.formbuilder.group({
    correo: ['', Validators.required],
    contraseña: ['', Validators.required],
  })
  mensaje: any;
  isauth = false; 
  isAdmin =  true;
  

  userservice:UserserviceService = inject(UserserviceService);
  constructor(router:Router, private usuarioService:HttpUsuarioService){
    this.router=router;
  }

  login(tipo:number){
    this.usuarioService.getLogin(this.loginGroup.value,tipo).subscribe(data => {
      this.mensaje=data;
      console.log(this.mensaje);
      if(this.mensaje.respuesta=="true"){
        if(tipo==1){
          this.userservice.saveuser(this.mensaje.login[0].correo,this.mensaje.login[0].id,tipo);
          this.router.navigate(['/horarios']);
        }
        else if(tipo==2){
          this.userservice.saveuser(this.mensaje.login[0].correo,this.mensaje.login[0].id,tipo);
          this.router.navigate(['/inventario']);
        }
        const btn = document.getElementById('sa') as HTMLButtonElement;
       
        btn.innerHTML=this.mensaje.login[0].nombre;
        this.isauth = true;
      }
    })
  }

  logout(){
    
  }

  /*usuario:{namee:string, avatarr:string, tipoo:number, password:string}=
  {
    namee:'',
    avatarr:'',
    tipoo:0, 
    password:''
  };
  isauth = false; 

  isInvalid = false;
  isAdmin =  true;

  private formBuilder = new FormBuilder();
  logingForm = this.formBuilder.group({
    email:['',Validators.required],
    password:['',Validators.required]
  })

  guardar(){
    console.log(this.logingForm);
    this.isInvalid = !this.logingForm.controls.email.valid;
    console.log(this.isInvalid)
  }

  constructor(private router: Router){
  }

  loging(){
    this.usuario.namee="Harold";
    this.usuario.avatarr="logo.jpg";
    this.usuario.tipoo=0;
    this.isauth=true;
    this.usuario.password="1234";
    this.router.navigate(['/inicio']);
  }
   
  logout(){
    this.usuario.namee="";
    this.usuario.avatarr="";
    this.usuario.tipoo=0;
    this.usuario.password="";
    this.isauth=false;
  }
 */
}

