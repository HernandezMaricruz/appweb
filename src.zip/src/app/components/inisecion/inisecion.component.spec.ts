import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InisecionComponent } from './inisecion.component';

describe('InisecionComponent', () => {
  let component: InisecionComponent;
  let fixture: ComponentFixture<InisecionComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [InisecionComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(InisecionComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
