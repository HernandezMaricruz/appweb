


import { Routes, RouterModule } from '@angular/router';
import { InicioComponent } from './paginas/inicio/inicio.component';
import { CitasComponent } from './components/citas/citas.component';
import { InformacionComponent } from './paginas/informacion/informacion.component';
import { HorariosComponent } from './paginas/horarios/horarios.component';
import { PersonalComponent } from './paginas/personal/personal.component';
import { InventarioComponent } from './paginas/inventario/inventario.component';
import { RegistrarComponent } from './paginas/registrar/registrar.component';
import { BuscarComponent } from './paginas/inventario/buscar/buscar.component';
import { Page404Component } from './paginas/page404/page404.component';
import { Component } from '@angular/core';
import { InisecionComponent } from './components/inisecion/inisecion.component';
import { HomeComponent } from './components/home/home.component';
import { InformacionUComponent } from './paginasUsuario/informacionU/informacionU.component';


export const routes: Routes = [{
     path: '', 
     redirectTo: '/inicio', 
     pathMatch: 'full' 
},   
{ path: "home",
  component: HomeComponent
},
    { path: "inicio", 
      component: InicioComponent 
    },
    { path: "citas", 
      component: CitasComponent 
    },
    { path: "informacion", 
      component: InformacionComponent 
    },
    { path: "horarios", 
      component: HorariosComponent 
    },
    { path: "personal", 
      component: PersonalComponent 
    },
    { path: "inventario", 
      component: InventarioComponent 
    },
    { path: "registrar", 
      component: RegistrarComponent 
    },
    { path: "inventario/buscar", 
      component: BuscarComponent 
    },
    {
      path: "login",
      component: InisecionComponent,
    },
    /*{
      path: "infousu",
      component : InfousuComponent
    },*/
    { path: "**", 
      component: Page404Component 
    },
    { path: "informacionU", 
      component: InformacionUComponent
    },
];

export class AppRoutingModule { }
