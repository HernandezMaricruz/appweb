import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpRegistrarService } from '../../../services/http-registrar.service';
import { FormsModule } from '@angular/forms'; // Importar FormsModule
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-registrar',
  standalone: true, // Indicar que es un standalone component
  imports: [FormsModule, CommonModule, ReactiveFormsModule], // Importar FormsModule aquí
  templateUrl: './registrar.component.html',
  styleUrls: ['./registrar.component.css']
})
export class RegistrarComponent implements OnInit {
  registroForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder, private registrarService: HttpRegistrarService) {
    this.registroForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      cantidad: ['', Validators.required],
      fecha: ['', Validators.required],
      descripcion: ['', Validators.required]
    });
  }

  ngOnInit(): void {}

  registrarMedicamento() {
    const medicamento = this.registroForm.value;
    this.registrarService.registrarMedicamento(medicamento).subscribe({
      next: () => {
        alert('Medicamento registrado exitosamente');
        this.registroForm.reset();
      },
      error: () => alert('Error al registrar el medicamento')
    });
  }
}
