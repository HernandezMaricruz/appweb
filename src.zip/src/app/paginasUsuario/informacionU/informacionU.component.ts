import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpInformacionService } from '../../services/http-informacion.service';
import { FormsModule } from '@angular/forms'; // Importar FormsModule
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';

@Component({
  selector: 'app-informacionU',
  standalone: true, // Standalone component
  imports: [FormsModule, CommonModule, ReactiveFormsModule],
  templateUrl: './informacionU.component.html',
  styleUrls: ['./informacionU.component.css']
})
export class InformacionUComponent implements OnInit {
  noticiaForm: FormGroup;
  noticias: any[] = [];

  constructor(
    private formBuilder: FormBuilder,
    private informacionService: HttpInformacionService
  ) {
    this.noticiaForm = this.formBuilder.group({
      titulo: ['', Validators.required],
      descripcion: ['', Validators.required],
      fecha: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.cargarNoticias();
  }

  // Cargar noticias desde el servicio
  cargarNoticias() {
    this.informacionService.getNoticias().subscribe((data) => {
      this.noticias = data;
    });
  }

  // Agregar una nueva noticia
  agregarNoticia() {
    const nuevaNoticia = this.noticiaForm.value;
    this.informacionService.agregarNoticia(nuevaNoticia).subscribe({
      next: () => {
        alert('Noticia agregada exitosamente');
        this.noticiaForm.reset();
        this.cargarNoticias();
      },
      error: () => alert('Error al agregar la noticia')
    });
  }

  // Eliminar una noticia
  eliminarNoticia(id: number) {
    this.informacionService.eliminarNoticia(id).subscribe({
      next: () => {
        alert('Noticia eliminada');
        this.cargarNoticias();
      },
      error: () => alert('Error al eliminar la noticia')
    });
  }

  // Editar una noticia (opcional)
  editarNoticia(noticia: any) {
    this.noticiaForm.patchValue(noticia);
  }
}
