import { Component } from '@angular/core';
import { HeaderComponent } from '../../components/header/header.component';
import { VistaComponent } from '../../components/vista/vista.component';

@Component({
  selector: 'app-personal',
  standalone: true,
  imports: [HeaderComponent, VistaComponent],
  templateUrl: './personal.component.html',
  styleUrl: './personal.component.css'
})
export class PersonalComponent {

}
