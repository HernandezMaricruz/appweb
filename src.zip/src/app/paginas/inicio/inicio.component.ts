import { Component } from '@angular/core';
import { RouterLinkActive, RouterLink, RouterOutlet } from '@angular/router';
import { HomeComponent } from '../../components/home/home.component';
import { HeaderComponent } from '../../components/header/header.component';
import { VistaComponent } from '../../components/vista/vista.component';

@Component({
  selector: 'app-inicio',
  standalone: true,
  imports: [RouterLinkActive, RouterLink, RouterOutlet, HeaderComponent, VistaComponent],
  templateUrl: './inicio.component.html',
  styleUrl: './inicio.component.css'
})
export class InicioComponent {

}
