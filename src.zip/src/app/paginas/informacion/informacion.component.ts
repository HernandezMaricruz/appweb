import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpInformacionService } from '../../services/http-informacion.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';  
import { HeaderComponent } from '../../components/header/header.component';
import { VistaComponent } from '../../components/vista/vista.component';

@Component({
  selector: 'app-informacion',
  standalone: true, // Indicar que es un standalone component
  imports: [FormsModule, CommonModule, ReactiveFormsModule, HeaderComponent, VistaComponent],
  templateUrl: './informacion.component.html',
  styleUrls: ['./informacion.component.css']
})
export class InformacionComponent implements OnInit {
  noticias: any[] = [];
  mostrarModal: boolean = false;
  esModoEdicion: boolean = false;
  noticiaSeleccionada: any | null = null;

  modalForm: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private informacionService: HttpInformacionService
  ) {
    this.modalForm = this.formBuilder.group({
      titulo: ['', Validators.required],
      descripcion: ['', Validators.required],
      fecha: ['', Validators.required]
    });
  }

  ngOnInit(): void {
    this.cargarNoticias();
  }

  cargarNoticias() {
    this.informacionService.getNoticias().subscribe((data) => {
      this.noticias = data;
    });
  }

  abrirModalAgregar() {
    this.esModoEdicion = false;
    this.modalForm.reset();
    this.mostrarModal = true;
  }

  abrirModalEditar(noticia: any) {
    this.esModoEdicion = true;
    this.noticiaSeleccionada = noticia;
    this.modalForm.patchValue(noticia);
    this.mostrarModal = true;
  }

  cerrarModal() {
    this.mostrarModal = false;
    this.noticiaSeleccionada = null;
    this.modalForm.reset();
  }

  agregarNoticia() {
    if (this.modalForm.invalid) return;

    const nuevaNoticia = this.modalForm.value;
    this.informacionService.agregarNoticia(nuevaNoticia).subscribe(() => {
      alert('Noticia agregada exitosamente');
      this.cerrarModal();
      this.cargarNoticias();
    });
  }

  guardarCambios() {
    if (!this.noticiaSeleccionada || this.modalForm.invalid) return;

    const noticiaEditada = {
      ...this.noticiaSeleccionada,
      ...this.modalForm.value
    };

    this.informacionService.actualizarNoticia(noticiaEditada.id, noticiaEditada).subscribe(() => {
      alert('Noticia actualizada exitosamente');
      this.cerrarModal();
      this.cargarNoticias();
    });
  }

  eliminarNoticia(id: number) {
    this.informacionService.eliminarNoticia(id).subscribe(() => {
      alert('Noticia eliminada');
      this.cargarNoticias();
    });
  }
}
