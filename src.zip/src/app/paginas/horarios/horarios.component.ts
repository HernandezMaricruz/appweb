import { Component } from '@angular/core';
import { RouterLinkActive, RouterLink, RouterOutlet } from '@angular/router';
import { VistaComponent } from '../../components/vista/vista.component';
import { HeaderComponent } from '../../components/header/header.component';

@Component({
  selector: 'app-horarios',
  standalone: true,
  imports: [RouterLinkActive, RouterLink, RouterOutlet, VistaComponent, HeaderComponent],
  templateUrl: './horarios.component.html',
  styleUrl: './horarios.component.css'
})
export class HorariosComponent {

}
