  import { CommonModule } from '@angular/common';
  import { FormsModule, ReactiveFormsModule } from '@angular/forms';  
  import { Component, OnInit } from '@angular/core';
  import { FormBuilder, FormGroup, Validators } from '@angular/forms';
  import { HttpInventarioService } from '../../services/http-inventario.service';
import { HeaderComponent } from '../../components/header/header.component';
import { VistaComponent } from '../../components/vista/vista.component';

@Component({
  selector: 'app-inventario',
  standalone: true, // Indicar que es un standalone component
  imports: [FormsModule, CommonModule, ReactiveFormsModule, HeaderComponent, VistaComponent], // Importar FormsModule aquí
  templateUrl: './inventario.component.html',
  styleUrls: ['./inventario.component.css'],
})
export class InventarioComponent implements OnInit {
  medicamentosForm: FormGroup;
  medicamentos: any[] = [];
  mostrarModal: boolean = false;
  medicamentoSeleccionado: any | null = null;

  constructor(
    private formBuilder: FormBuilder,
    private inventarioService: HttpInventarioService
  ) {
    this.medicamentosForm = this.formBuilder.group({
      nombre: ['', Validators.required],
      cantidad: ['', [Validators.required, Validators.min(1)]],
      fecha: ['', Validators.required],
      descripcion: ['', Validators.required],
    });
  }

  ngOnInit(): void {
    this.obtenerMedicamentos();
  }

  obtenerMedicamentos(): void {
    this.inventarioService.obtenerMedicamentos().subscribe({
      next: (data) => (this.medicamentos = data),
      error: (err) => console.error('Error al cargar medicamentos', err),
    });
  }

  abrirModal(medicamento: any): void {
    this.mostrarModal = true;
    this.medicamentoSeleccionado = medicamento;
    this.medicamentosForm.patchValue({
      nombre: medicamento.nombre,
      cantidad: medicamento.cantidad,
      fecha: medicamento.fecha,
      descripcion: medicamento.descripcion,
    });
  }

  guardarCambios(): void {
    if (!this.medicamentoSeleccionado || this.medicamentosForm.invalid) return;

    const medicamentoEditado = {
      id: this.medicamentoSeleccionado.id,
      ...this.medicamentosForm.value,
    };

    this.inventarioService.actualizarMedicamento(
      medicamentoEditado.id,
      medicamentoEditado
    ).subscribe({
      next: () => {
        alert('Medicamento actualizado con éxito');
        this.cerrarModal();
        this.obtenerMedicamentos();
      },
      error: (err) => {
        console.error('Error al actualizar el medicamento', err);
        alert('Error al actualizar el medicamento');
      },
    });
  }

  cerrarModal(): void {
    this.mostrarModal = false;
    this.medicamentoSeleccionado = null;
    this.medicamentosForm.reset();
  }

  eliminarMedicamento(id: number): void {
    this.inventarioService.eliminarMedicamento(id).subscribe({
      next: () => {
        alert('Medicamento eliminado');
        this.obtenerMedicamentos();
      },
      error: () => alert('Error al eliminar el medicamento'),
    });
  }
}