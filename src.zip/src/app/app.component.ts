import { Component } from '@angular/core';
import { RouterOutlet, RouterLink } from '@angular/router';
import { VistaComponent } from './components/vista/vista.component';
import { HeaderComponent } from './components/header/header.component';
import { InicioComponent } from './paginas/inicio/inicio.component';
import { InisecionComponent } from './components/inisecion/inisecion.component';
import { CitasComponent } from './components/citas/citas.component';
import { MenuComponent } from './components/menu/menu.component';
import { HomeComponent } from "./components/home/home.component";


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, RouterLink, VistaComponent, HeaderComponent, InicioComponent, InisecionComponent, CitasComponent, MenuComponent, HomeComponent],  
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'MediTec2.0';
}
