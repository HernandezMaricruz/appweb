import { TestBed } from '@angular/core/testing';

import { HttpRegistrarService } from './http-registrar.service';

describe('HttpRegistrarService', () => {
  let service: HttpRegistrarService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpRegistrarService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
