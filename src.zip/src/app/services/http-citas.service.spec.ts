import { TestBed } from '@angular/core/testing';

import { HttpCitasService } from './http-citas.service';

describe('HttpCitasService', () => {
  let service: HttpCitasService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpCitasService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
