import { TestBed } from '@angular/core/testing';

import { HttpUsuarioService } from './http-usuario.service';

describe('HttpUsuarioService', () => {
  let service: HttpUsuarioService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpUsuarioService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
