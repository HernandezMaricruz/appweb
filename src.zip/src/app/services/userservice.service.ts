import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class UserserviceService {
  usuario:any = {
    'correo':'',
    'id':0,
    'tipo':0,
  }
  

  constructor() { }

  saveuser(correo:string, id:number, tipo:number){
    this.usuario.correo=correo;
    this.usuario.id=id;
    this.usuario.tipo=tipo;
  }

  getuser(){
    return this.usuario;
  }

}
