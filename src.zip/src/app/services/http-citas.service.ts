import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class HttpCitasService {
  private apiUrl = 'http://127.0.0.1:8000/api/citas';

  constructor(private http: HttpClient) {}

  agendarCita(data: any) {
    return this.http.post(`${this.apiUrl}/agendar`, data);
  }

  getCitasPorDia(fecha: string) {
    return this.http.get<any[]>(`${this.apiUrl}/fecha/${fecha}`);
  }

  getTodasLasCitas() {
    return this.http.get<any[]>(`${this.apiUrl}`);
  }

  eliminarCita(id: number) {
    return this.http.delete(`${this.apiUrl}/${id}`);
  }
}
