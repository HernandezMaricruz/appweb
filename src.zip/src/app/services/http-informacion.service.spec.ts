import { TestBed } from '@angular/core/testing';

import { HttpInformacionService } from './http-informacion.service';

describe('HttpInformacionService', () => {
  let service: HttpInformacionService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpInformacionService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
