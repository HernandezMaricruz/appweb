import { TestBed } from '@angular/core/testing';

import { HttpsLoginsService } from './https-logins.service';

describe('HttpsLoginsService', () => {
  let service: HttpsLoginsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HttpsLoginsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
