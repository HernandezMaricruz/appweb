import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class HttpUsuarioService {
  proyecto = 'http://127.0.0.1:8000/api'

  private isAuth = false;

  constructor(protected http:HttpClient) { }

  getUsuario(id:any){
    return this.http.get(this.proyecto+'/usuario/get/'+id,{responseType:'json'});
  }

  getLogin(parametros:any, tipo:any) {
    let params = new HttpParams();
    Object.keys(parametros).forEach(key => {
      if(parametros[key] !==null && parametros[key]!==undefined){
        params = params.append(key, parametros[key]);
      }
    });

    return this.http.get(this.proyecto+'/usuario/login/'+tipo,{responseType:'json',params })
  }

  createUsuario(data:any){
    return this.http.post(this.proyecto+'/usuario/agregar',data,{responseType:'json'})
  }

  modificarUsuario(data:any){
    return this.http.put(this.proyecto+'/usuario/edit',data,{responseType:'json'})
  }

  eliminarUsuario(data:any){
    return this.http.post(this.proyecto+'/usuario/agregar',data,{responseType:'json'})
  }
}
